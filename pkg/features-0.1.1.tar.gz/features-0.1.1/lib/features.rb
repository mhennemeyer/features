current_dir = File.dirname(File.expand_path(__FILE__))

require current_dir + "/string_extension.rb"
require current_dir + "/feature.rb"
require current_dir + "/scenario.rb"
require current_dir + "/step.rb"
require current_dir + "/suite.rb"
require current_dir + "/parser.rb"
require current_dir + "/rails.rb"
require current_dir + "/objc.rb"