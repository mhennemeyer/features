lib = File.dirname(__FILE__) + "/ObjC"

require lib + "/objc_feature.rb"
require lib + "/objc_scenario.rb"
require lib + "/objc_step.rb"
require lib + "/objc_suite.rb"