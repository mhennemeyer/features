class Suite
end