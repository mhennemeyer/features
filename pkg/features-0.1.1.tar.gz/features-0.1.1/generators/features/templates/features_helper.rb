current_dir = File.dirname(File.expand_path(__FILE__))
require current_dir + "/../../test_helper.rb"
require current_dir + "/custom_steps.rb"
require current_dir + "/features_test_case_class.rb"