module CustomSteps
  
  # Add real step definitions here
  def when_I_say___(string)
    puts string
  end
end