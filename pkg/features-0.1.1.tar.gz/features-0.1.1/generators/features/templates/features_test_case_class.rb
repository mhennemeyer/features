class FeaturesTestCaseClass < ActionController::IntegrationTest
  include CustomSteps
end